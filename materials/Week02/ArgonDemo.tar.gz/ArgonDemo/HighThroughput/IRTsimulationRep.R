# conducts a  unidimensional IRT analysis of the one simulated data set with 1000 people

if (!require(mirt)) install.packages("mirt",
                                     repos = "http://cran.us.r-project.org", 
                                     lib = "/Users/jtemplin/R/x86_64-pc-linux-gnu-library/4.2")
library(mirt)

# get replication number from command line arguments:
args = commandArgs(trailingOnly = TRUE)
repnumber = as.numeric(args[1])

# set random number seed
seed = 20230817 + repnumber
set.seed(seed = seed)

# simulate data
nObs = 1000
nItems = 20

# generate item parameters
a = rlnorm(n = nItems, meanlog = 0, sdlog = .2)
b = rnorm(n = nItems, mean = 0, sd = 1)

# generate person parameters 
theta = rnorm(n = nObs, mean = 0, sd = 1)

# generate data
data = matrix(data = NA, nrow = nObs, ncol = nItems)
for (item in 1:20){
  linearPredictor = a[item]*(theta-b[item])
  itemProb = pnorm(linearPredictor)
  data[,item] = rbinom(n = nObs, size = 1, prob = itemProb)
}
colnames(data) = paste0("item", 1:nItems)

modelU2PL = mirt(data = data, model = 1)

modelCoefs = coef(modelU2PL, IRTpars = TRUE)
aEst = unlist(lapply(X = modelCoefs, FUN = function(x) return(x[1,1])))
aEst = aEst[1:nItems]

bEst = unlist(lapply(X = modelCoefs, FUN = function(x) return(x[1,2])))
bEst = bEst[1:nItems]

thetaEst = fscores(modelU2PL)

itemResults = data.frame(
  trueA = a,
  trueB = b,
  aEst = aEst,
  bEst = bEst
)

personResults = data.frame(
  trueTheta = theta,
  thetaEst = as.numeric(thetaEst)
)


aCor = cor(itemResults$trueA, itemResults$aEst)
bCor = cor(itemResults$trueB, itemResults$bEst)
thetaCor = cor(personResults$trueTheta, personResults$thetaEst)

aRMSE = sqrt(mean((itemResults$trueA - itemResults$aEst)^2))
bRMSE = sqrt(mean((itemResults$trueB - itemResults$bEst)^2))
thetaRMSE = sqrt(mean((personResults$trueTheta - personResults$thetaEst)^2))

aBias = mean(itemResults$aEst - itemResults$trueA)
bBias = mean(itemResults$bEst - itemResults$trueB)
thetaBias = mean(personResults$trueTheta - personResults$thetaEst)

simResults = list()
simResults$itemResults = itemResults
simResults$personResults = personResults
simResults$results = data.frame(aCor = aCor, bCor = bCor, thetaCor = thetaCor,
                                aRMSE = aRMSE, bRMSE = bRMSE, thetaRMSE = thetaRMSE,
                                aBias = aBias, bBias = bBias, thetaBias = thetaBias)

save(simResults, file = paste0("simResultsRep", repnumber, ".RData"))
