# list files in directory
directoryFiles = dir()

# list only simluation results files
resultsFiles = directoryFiles[grep(pattern = "simResultsRep", x = directoryFiles)]

# load and process simulation results
finalResults = NULL
for (file in 1:length(resultsFiles)){
  load(file = resultsFiles[file])
  finalResults = rbind(finalResults, simResults$results)
}

summary(finalResults)
apply(X = finalResults, MARGIN = 2, FUN = mean)
apply(X = finalResults, MARGIN = 2, FUN = sd)
nrow(finalResults)
save(finalResults, file = "finalResults.RData")