# conducts a  unidimensional IRT analysis of the Tatsuoka Fraction Subtraction data set from the CDM R package using mirt

if (!require(mirt)) install.packages("mirt", 
                                     repos = "http://cran.us.r-project.org", 
                                     lib = "/Users/jtemplin/R/x86_64-pc-linux-gnu-library/4.2")
library(mirt)

if (!require(CDM)) install.packages("CDM", 
                                    repos = "http://cran.us.r-project.org", 
                                    lib = "/Users/jtemplin/R/x86_64-pc-linux-gnu-library/4.2")
library(CDM)

FSdata = fraction.subtraction.data
FSQmatrix = fraction.subtraction.qmatrix

# estimate model
modelU2PL = mirt(data = FSdata, model = 1)

# print model parameters
print(coef(modelU2PL, IRTpars=TRUE))

# save the analysis model file
save(modelU2PL, FSdata, FSQmatrix, file = "IRTmodelFSdata.RData")
