#this file uses the R scripts from Dr. Andre A. Rupp and Dr. Oliver Wilhelm; Available from:
#http://www.education.umd.edu/EDMS/fac/Rupp/R%20Files%20for%20Mplus%20Input%20File%20Generation.zip

#SET CURRENT DIRECTORY -----------------------------------------------------------------------------------
current_dir = getwd()

#INITIALIZE ALL FUNCTIONS --------------------------------------------------------------------------------
#this routine: (1) formats the Chapter 9 data in accordance with the R functions expectations
#              (2) writes the Mplus script
#              (3) runs Mplus using the MplusAutomation package
#              (4) collects Mplus output

#load MplusAutomation:
if (tryCatch(require("MplusAutomation")) == FALSE){
  install.packages("MplusAutomation")
  library(MplusAutomation)
}

#set directory to location of example R script:
#setwd(current_dir)

#read in R scripts from Rupp and Wilhelm:
source("Functions/MplusDCM.R")

#ANALYZE EXAMPLE DATA FILE ------------------------------------------------------------------------------

#read in original data and create id variable
data = read.table(file = "dtmrdemo.dat")
paste("X", rep(1:27), sep="")
colnames(data) = c(paste("X", rep(1:27), sep=""), "TrueClass")
data$id = 1:dim(data)[1]

#read in qmatrix file
qmatrix = read.csv("qmatrix.csv")

analysis_folder = paste(current_dir, "Analyses", sep = "/")
setwd(analysis_folder)

#write data set to file for reading by function
write.table(x = data[c("id", paste("X", rep(1:27), sep=""))], file = "inputdata.dat", 
            col.names = FALSE, quote = FALSE, row.names = FALSE)

#create input file
myoutput = generate.mplus.input(filename_ds = "inputdata.dat", qmatrix = qmatrix[,2:4], input_file = "dtmr.inp", PreAddVars = "id")

#run Mplus
myanalysis = runModels(showOutput = TRUE)

#gather results
myresults = readModels(target = "dtmrExample.out")
myresults$summaries

#display LCDM item parameters:
items = myresults$parameters$unstandardized[which(myresults$parameters$unstandardized$paramHeader == "New.Additional.Parameters"),]

#display LCDM structrual parameters:
struct = myresults$parameters$unstandardized[which(myresults$parameters$unstandardized$paramHeader == "Means"),]

# convert to probabilities
logMeans = c(struct$est, 0)
logMeans = exp(logMeans)/sum(exp(logMeans))
